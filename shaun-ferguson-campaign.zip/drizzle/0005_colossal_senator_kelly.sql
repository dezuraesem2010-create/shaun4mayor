CREATE TABLE `batch_config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchSize` int DEFAULT 150,
	`totalContacts` int DEFAULT 9000,
	`totalBatches` int DEFAULT 60,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `batch_config_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `campaign_backups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileUrl` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`type` enum('contacts','assignments','metrics') DEFAULT 'contacts',
	CONSTRAINT `campaign_backups_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contactId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`precinct` varchar(255),
	`neighborhood` varchar(255),
	`assignedBatch` int,
	`assignedVolunteer` varchar(255),
	`contacted` boolean DEFAULT false,
	`responseStatus` enum('Supporter','Opposed','Undecided','Volunteer','Do Not Contact','No Response Yet') DEFAULT 'No Response Yet',
	`volunteerInterest` boolean DEFAULT false,
	`doNotContact` boolean DEFAULT false,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contacts_id` PRIMARY KEY(`id`),
	CONSTRAINT `contacts_contactId_unique` UNIQUE(`contactId`)
);
--> statement-breakpoint
CREATE TABLE `message_templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`label` varchar(10) NOT NULL,
	`theme` varchar(255) NOT NULL,
	`messageText` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `message_templates_id` PRIMARY KEY(`id`),
	CONSTRAINT `message_templates_label_unique` UNIQUE(`label`)
);
--> statement-breakpoint
CREATE TABLE `volunteer_assignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchNumber` int NOT NULL,
	`volunteerName` varchar(255),
	`volunteerEmail` varchar(320),
	`startContactId` int,
	`endContactId` int,
	`totalContacts` int DEFAULT 0,
	`progressStatus` enum('Not Started','In Progress','Completed') DEFAULT 'Not Started',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `volunteer_assignments_id` PRIMARY KEY(`id`),
	CONSTRAINT `volunteer_assignments_batchNumber_unique` UNIQUE(`batchNumber`)
);
