import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const contacts = mysqlTable("contacts", {
  id: int("id").autoincrement().primaryKey(),
  contactId: int("contactId").notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  precinct: varchar("precinct", { length: 255 }),
  neighborhood: varchar("neighborhood", { length: 255 }),
  assignedBatch: int("assignedBatch"),
  assignedVolunteer: varchar("assignedVolunteer", { length: 255 }),
  contacted: boolean("contacted").default(false),
  responseStatus: mysqlEnum("responseStatus", [
    "Supporter",
    "Opposed",
    "Undecided",
    "Volunteer",
    "Do Not Contact",
    "No Response Yet",
  ]).default("No Response Yet"),
  volunteerInterest: boolean("volunteerInterest").default(false),
  doNotContact: boolean("doNotContact").default(false),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const volunteerAssignments = mysqlTable("volunteer_assignments", {
  id: int("id").autoincrement().primaryKey(),
  batchNumber: int("batchNumber").notNull().unique(),
  volunteerName: varchar("volunteerName", { length: 255 }),
  volunteerEmail: varchar("volunteerEmail", { length: 320 }),
  startContactId: int("startContactId"),
  endContactId: int("endContactId"),
  totalContacts: int("totalContacts").default(0),
  progressStatus: mysqlEnum("progressStatus", ["Not Started", "In Progress", "Completed"]).default("Not Started"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const messageTemplates = mysqlTable("message_templates", {
  id: int("id").autoincrement().primaryKey(),
  label: varchar("label", { length: 10 }).notNull().unique(),
  theme: varchar("theme", { length: 255 }).notNull(),
  messageText: text("messageText").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const batchConfig = mysqlTable("batch_config", {
  id: int("id").autoincrement().primaryKey(),
  batchSize: int("batchSize").default(150),
  totalContacts: int("totalContacts").default(9000),
  totalBatches: int("totalBatches").default(60),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const campaignBackups = mysqlTable("campaign_backups", {
  id: int("id").autoincrement().primaryKey(),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  type: mysqlEnum("type", ["contacts", "assignments", "metrics"]).default("contacts"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Contact = typeof contacts.$inferSelect;
export type InsertContact = typeof contacts.$inferInsert;
export type VolunteerAssignment = typeof volunteerAssignments.$inferSelect;
export type InsertVolunteerAssignment = typeof volunteerAssignments.$inferInsert;
export type MessageTemplate = typeof messageTemplates.$inferSelect;
export type BatchConfig = typeof batchConfig.$inferSelect;
export type CampaignBackup = typeof campaignBackups.$inferSelect;
