DROP TABLE `batch_config`;--> statement-breakpoint
DROP TABLE `campaign_backups`;--> statement-breakpoint
DROP TABLE `contacts`;--> statement-breakpoint
DROP TABLE `message_templates`;--> statement-breakpoint
DROP TABLE `volunteer_assignments`;