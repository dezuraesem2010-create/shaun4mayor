CREATE TABLE `batch_config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchSize` int NOT NULL DEFAULT 150,
	`totalContacts` int NOT NULL DEFAULT 9000,
	`totalBatches` int NOT NULL DEFAULT 60,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `batch_config_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `campaign_backups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`filename` varchar(500) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileKey` varchar(500) NOT NULL,
	`backupType` enum('contacts','volunteers','full') NOT NULL DEFAULT 'full',
	`fileSizeBytes` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `campaign_backups_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contactId` int NOT NULL,
	`name` varchar(255),
	`phone` varchar(30),
	`precinct` varchar(100),
	`neighborhood` varchar(255),
	`assignedBatch` int,
	`assignedVolunteer` varchar(255),
	`contacted` boolean NOT NULL DEFAULT false,
	`responseStatus` enum('No Response Yet','Supporter','Opposed','Undecided','Volunteer','Do Not Contact') NOT NULL DEFAULT 'No Response Yet',
	`volunteerInterest` boolean NOT NULL DEFAULT false,
	`doNotContact` boolean NOT NULL DEFAULT false,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contacts_id` PRIMARY KEY(`id`),
	CONSTRAINT `contacts_contactId_unique` UNIQUE(`contactId`)
);
--> statement-breakpoint
CREATE TABLE `message_templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`label` varchar(10) NOT NULL,
	`theme` varchar(100) NOT NULL,
	`messageText` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `message_templates_id` PRIMARY KEY(`id`),
	CONSTRAINT `message_templates_label_unique` UNIQUE(`label`)
);
--> statement-breakpoint
CREATE TABLE `volunteer_assignments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchNumber` int NOT NULL,
	`volunteerName` varchar(255),
	`volunteerEmail` varchar(320),
	`startContactId` int NOT NULL,
	`endContactId` int NOT NULL,
	`totalContacts` int NOT NULL DEFAULT 150,
	`progressStatus` enum('Not Started','In Progress','Completed') NOT NULL DEFAULT 'Not Started',
	`assignedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `volunteer_assignments_id` PRIMARY KEY(`id`),
	CONSTRAINT `volunteer_assignments_batchNumber_unique` UNIQUE(`batchNumber`)
);
