import { eq, and, like } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, contacts, volunteerAssignments, messageTemplates, batchConfig } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      if (user[field] !== undefined) {
        values[field] = user[field] ?? null;
        updateSet[field] = user[field] ?? null;
      }
    });

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await (db as any).insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await (db as any).select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Contacts ───────────────────────────────────────────────────────────────
export async function listContacts() {
  const db = await getDb();
  if (!db) return [];
  return (await (db as any).select().from(contacts)) || [];
}

export async function getContact(contactId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await (db as any).select().from(contacts).where(eq(contacts.contactId, contactId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createContact(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await (db as any).insert(contacts).values(data);
  return data;
}

export async function updateContact(contactId: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await (db as any).update(contacts).set(data).where(eq(contacts.contactId, contactId));
  return getContact(contactId);
}

export async function bulkCreateContacts(data: any[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await (db as any).insert(contacts).values(data);
  return { count: data.length };
}

// ─── Volunteer Assignments ──────────────────────────────────────────────────
export async function listVolunteerAssignments() {
  const db = await getDb();
  if (!db) return [];
  return (await (db as any).select().from(volunteerAssignments)) || [];
}

export async function getVolunteerAssignment(batchNumber: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await (db as any).select().from(volunteerAssignments).where(eq(volunteerAssignments.batchNumber, batchNumber)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createVolunteerAssignment(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await (db as any).insert(volunteerAssignments).values(data);
  return data;
}

export async function updateVolunteerAssignment(batchNumber: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await (db as any).update(volunteerAssignments).set(data).where(eq(volunteerAssignments.batchNumber, batchNumber));
  return getVolunteerAssignment(batchNumber);
}

// ─── Message Templates ──────────────────────────────────────────────────────
export async function listMessageTemplates() {
  const db = await getDb();
  if (!db) return [];
  return (await (db as any).select().from(messageTemplates)) || [];
}

export async function getMessageTemplate(label: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await (db as any).select().from(messageTemplates).where(eq(messageTemplates.label, label)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// // ─── Batch Summary with Progress ──────────────────────────────────────────
export async function getBatchSummaryWithProgress() {
  const db = await getDb();
  if (!db) return [];
  
  const assignments = await (db as any).select().from(volunteerAssignments);
  const allContacts = await (db as any).select().from(contacts);
  
  return assignments.map((assignment: any) => {
    const batchContacts = allContacts.filter((c: any) => c.assignedBatch === assignment.batchNumber);
    const contactsCompleted = batchContacts.filter((c: any) => c.contacted).length;
    
    return {
      ...assignment,
      contactsCompleted,
      totalContacts: assignment.totalContacts,
    };
  });
}

// ─── Batch Config ───────────────────────────────────────────────────────
export async function getBatchConfig() {
  const db = await getDb();
  if (!db) return null;
  const result = await (db as any).select().from(batchConfig).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateBatchConfig(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const config = await getBatchConfig();
  if (config) {
    await (db as any).update(batchConfig).set(data).where(eq(batchConfig.id, config.id));
  } else {
    await (db as any).insert(batchConfig).values(data);
  }
  return getBatchConfig();
}
