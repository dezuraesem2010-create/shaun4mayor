import { COOKIE_NAME } from "@shared/const";
import type { Contact } from "../drizzle/schema";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Contacts ───────────────────────────────────────────────────────────
  contacts: router({
    list: protectedProcedure.query(() => db.listContacts()),

    get: protectedProcedure
      .input(z.object({ contactId: z.number() }))
      .query(({ input }) => db.getContact(input.contactId)),

    create: protectedProcedure
      .input(
        z.object({
          contactId: z.number(),
          name: z.string(),
          phone: z.string(),
          precinct: z.string().optional(),
          neighborhood: z.string().optional(),
          assignedBatch: z.number().optional(),
          assignedVolunteer: z.string().optional(),
        })
      )
      .mutation(({ input }) => db.createContact(input)),

    update: protectedProcedure
      .input(
        z.object({
          contactId: z.number(),
          name: z.string().optional(),
          phone: z.string().optional(),
          precinct: z.string().optional(),
          neighborhood: z.string().optional(),
          assignedBatch: z.number().optional(),
          assignedVolunteer: z.string().optional(),
          contacted: z.boolean().optional(),
          responseStatus: z.enum(["Supporter", "Opposed", "Undecided", "Volunteer", "Do Not Contact", "No Response Yet"]).optional(),
          doNotContact: z.boolean().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(({ input }) => {
        const { contactId, ...data } = input;
        return db.updateContact(contactId, data);
      }),

    bulkImport: adminProcedure
      .input(
        z.object({
          contacts: z.array(
            z.object({
              contactId: z.number(),
              name: z.string(),
              phone: z.string(),
              precinct: z.string().optional(),
              neighborhood: z.string().optional(),
              assignedBatch: z.number().optional(),
              assignedVolunteer: z.string().optional(),
            })
          ),
        })
      )
      .mutation(({ input }) => db.bulkCreateContacts(input.contacts)),

    export: protectedProcedure.query(() => db.listContacts()),
  }),

  // ─── Volunteers ──────────────────────────────────────────────────────────
  volunteers: router({
    list: protectedProcedure.query(() => db.listVolunteerAssignments()),

    get: protectedProcedure
      .input(z.object({ batchNumber: z.number() }))
      .query(({ input }) => db.getVolunteerAssignment(input.batchNumber)),

    create: adminProcedure
      .input(
        z.object({
          batchNumber: z.number(),
          volunteerName: z.string(),
          volunteerEmail: z.string().email().optional(),
          startContactId: z.number(),
          endContactId: z.number(),
          totalContacts: z.number(),
        })
      )
      .mutation(({ input }) =>
        db.createVolunteerAssignment({
          batchNumber: input.batchNumber,
          volunteerName: input.volunteerName,
          volunteerEmail: input.volunteerEmail,
          startContactId: input.startContactId,
          endContactId: input.endContactId,
          totalContacts: input.totalContacts,
          progressStatus: "Not Started",
        })
      ),

    update: adminProcedure
      .input(
        z.object({
          batchNumber: z.number(),
          volunteerName: z.string().optional(),
          volunteerEmail: z.string().email().optional(),
          progressStatus: z.enum(["Not Started", "In Progress", "Completed"]).optional(),
        })
      )
      .mutation(({ input }) => {
        const { batchNumber, ...data } = input;
        return db.updateVolunteerAssignment(batchNumber, data);
      }),
  }),

  // ─── Dashboard ───────────────────────────────────────────────────────────
  dashboard: router({
    getMetrics: protectedProcedure.query(async () => {
      const allContacts = await db.listContacts();
      const assignments = await db.listVolunteerAssignments();

      const totalContacts = allContacts.length;
      const contactsAssigned = allContacts.filter((c: any) => c.assignedVolunteer).length;
      const contactsCompleted = allContacts.filter((c: any) => c.contacted).length;
      const supporters = allContacts.filter((c: any) => c.responseStatus === "Supporter").length;
      const undecided = allContacts.filter((c: any) => c.responseStatus === "Undecided").length;
      const opposed = allContacts.filter((c: any) => c.responseStatus === "Opposed").length;
      const volunteerRecruits = allContacts.filter((c: any) => c.responseStatus === "Volunteer").length;
      const doNotContact = allContacts.filter((c: any) => c.doNotContact).length;
      const noResponseYet = allContacts.filter((c: any) => c.responseStatus === "No Response Yet").length;
      const completionPercentage = totalContacts > 0 ? Math.round((contactsCompleted / totalContacts) * 100) : 0;

      return {
        totalContacts,
        contactsAssigned,
        contactsCompleted,
        supporters,
        undecided,
        opposed,
        volunteerRecruits,
        doNotContact,
        noResponseYet,
        completionPercentage,
      };
    }),

    getBatchSummary: protectedProcedure.query(async () => {
      return await db.getBatchSummaryWithProgress();
    }),

    getContactsByCategory: protectedProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        const allContacts = await db.listContacts();
        let filtered: any[] = [];

        switch (input.category) {
          case "total":
            filtered = allContacts;
            break;
          case "assigned":
            filtered = allContacts.filter((c: any) => c.assignedVolunteer);
            break;
          case "completed":
            filtered = allContacts.filter((c: any) => c.contacted);
            break;
          case "supporters":
            filtered = allContacts.filter((c: any) => c.responseStatus === "Supporter");
            break;
          case "undecided":
            filtered = allContacts.filter((c: any) => c.responseStatus === "Undecided");
            break;
          case "opposed":
            filtered = allContacts.filter((c: any) => c.responseStatus === "Opposed");
            break;
          case "volunteers":
            filtered = allContacts.filter((c: any) => c.responseStatus === "Volunteer");
            break;
          case "doNotContact":
            filtered = allContacts.filter((c: any) => c.doNotContact);
            break;
          case "noResponseYet":
            filtered = allContacts.filter((c: any) => c.responseStatus === "No Response Yet");
            break;
        }

        return filtered.map((c: any) => ({
          contactId: c.contactId,
          name: c.name,
          phone: c.phone,
          precinct: c.precinct,
          neighborhood: c.neighborhood,
          assignedBatch: c.assignedBatch,
          assignedVolunteer: c.assignedVolunteer,
          responseStatus: c.responseStatus,
          doNotContact: c.doNotContact,
          notes: c.notes,
        }));
      }),
  }),

  // ─── Templates ───────────────────────────────────────────────────────────
  templates: router({
    list: protectedProcedure.query(() => db.listMessageTemplates()),

    get: protectedProcedure
      .input(z.object({ label: z.string() }))
      .query(({ input }) => db.getMessageTemplate(input.label)),
  }),

  // ─── Batch Config ────────────────────────────────────────────────────────
  batchConfig: router({
    get: protectedProcedure.query(() => db.getBatchConfig()),

    update: adminProcedure
      .input(
        z.object({
          batchSize: z.number().optional(),
          totalContacts: z.number().optional(),
          totalBatches: z.number().optional(),
        })
      )
      .mutation(({ input }) => db.updateBatchConfig(input)),
  }),
});

export type AppRouter = typeof appRouter;
