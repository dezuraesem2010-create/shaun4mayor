import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user context for testing
function createMockContext(role: "admin" | "user" = "user"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("contacts router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createMockContext("user"));
  });

  it("should list contacts", async () => {
    const contacts = await caller.contacts.list({});
    expect(Array.isArray(contacts)).toBe(true);
  });

  it("should create a new contact", async () => {
    const newContact = await caller.contacts.create({
      contactId: 9001,
      name: "John Doe",
      phone: "555-1234",
      precinct: "Downtown",
      neighborhood: "Main Street",
      assignedBatch: 1,
      assignedVolunteer: "Jane Smith",
      notes: "Test contact",
    });

    expect(newContact).toBeDefined();
    expect(newContact.contactId).toBe(9001);
    expect(newContact.name).toBe("John Doe");
    expect(newContact.phone).toBe("555-1234");
    expect(newContact.contacted).toBe(false);
    expect(newContact.responseStatus).toBe("No Response Yet");
  });

  it("should get a specific contact", async () => {
    const contact = await caller.contacts.get({ contactId: 9001 });
    expect(contact).toBeDefined();
    expect(contact?.contactId).toBe(9001);
  });

  it("should update a contact", async () => {
    const updated = await caller.contacts.update({
      contactId: 9001,
      name: "Jane Doe",
      contacted: true,
      responseStatus: "Supporter",
    });

    expect(updated.name).toBe("Jane Doe");
    expect(updated.contacted).toBe(true);
    expect(updated.responseStatus).toBe("Supporter");
  });

  it("should filter contacts by batch", async () => {
    const contacts = await caller.contacts.list({ batch: 1 });
    expect(Array.isArray(contacts)).toBe(true);
  });

  it("should filter contacts by response status", async () => {
    const contacts = await caller.contacts.list({
      responseStatus: "Supporter",
    });
    expect(Array.isArray(contacts)).toBe(true);
  });

  it("should get contact count", async () => {
    const count = await caller.contacts.count();
    expect(typeof count).toBe("number");
    expect(count).toBeGreaterThanOrEqual(0);
  });

  it("should get contacts by batch", async () => {
    const contacts = await caller.contacts.getByBatch({
      batchNumber: 1,
      limit: 10,
    });
    expect(Array.isArray(contacts)).toBe(true);
  });
});

describe("volunteers router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createMockContext("admin"));
  });

  it("should list volunteer assignments", async () => {
    const assignments = await caller.volunteers.list();
    expect(Array.isArray(assignments)).toBe(true);
    expect(assignments.length).toBe(60); // Should have 60 batches
  });

  it("should get a specific volunteer assignment", async () => {
    const assignment = await caller.volunteers.get({ batchNumber: 1 });
    expect(assignment).toBeDefined();
    expect(assignment?.batchNumber).toBe(1);
    expect(assignment?.totalContacts).toBe(150);
  });

  it("should update volunteer assignment", async () => {
    const updated = await caller.volunteers.update({
      batchNumber: 1,
      volunteerName: "Alice Johnson",
      volunteerEmail: "alice@example.com",
      progressStatus: "In Progress",
    });

    expect(updated.volunteerName).toBe("Alice Johnson");
    expect(updated.volunteerEmail).toBe("alice@example.com");
    expect(updated.progressStatus).toBe("In Progress");
  });

  it("should prevent non-admins from creating assignments", async () => {
    const userCaller = appRouter.createCaller(createMockContext("user"));
    
    try {
      await userCaller.volunteers.create({
        batchNumber: 61,
        volunteerName: "Bob Smith",
        startContactId: 9001,
        endContactId: 9150,
        totalContacts: 150,
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });
});

describe("dashboard router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createMockContext("user"));
  });

  it("should get campaign metrics", async () => {
    const metrics = await caller.dashboard.getMetrics();
    expect(metrics).toBeDefined();
    expect(typeof metrics.totalContacts).toBe("number");
    expect(typeof metrics.contactsAssigned).toBe("number");
    expect(typeof metrics.contactsCompleted).toBe("number");
    expect(typeof metrics.supporters).toBe("number");
    expect(typeof metrics.completionPercentage).toBe("number");
  });

  it("should get batch summary", async () => {
    const summary = await caller.dashboard.getBatchSummary();
    expect(Array.isArray(summary)).toBe(true);
    expect(summary.length).toBe(60);

    const firstBatch = summary[0];
    expect(firstBatch.batchNumber).toBe(1);
    expect(typeof firstBatch.completionPercentage).toBe("number");
  });
});

describe("templates router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createMockContext("user"));
  });

  it("should list message templates", async () => {
    const templates = await caller.templates.list();
    expect(Array.isArray(templates)).toBe(true);
    expect(templates.length).toBe(5); // Should have 5 templates (A-E)
  });

  it("should get a specific template", async () => {
    const template = await caller.templates.get({ label: "A" });
    expect(template).toBeDefined();
    expect(template?.label).toBe("A");
    expect(template?.theme).toBe("Community Focus");
  });
});

describe("batch config router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createMockContext("user"));
  });

  it("should get batch configuration", async () => {
    const config = await caller.batchConfig.get();
    expect(config).toBeDefined();
    expect(config?.batchSize).toBe(150);
    expect(config?.totalContacts).toBe(9000);
    expect(config?.totalBatches).toBe(60);
  });
});
