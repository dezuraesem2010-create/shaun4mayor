import { useAuth } from "@/_core/hooks/useAuth";
import { LayoutDashboard, Users, MessageSquare, Zap, BookOpen, Upload, Settings, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  const navItems = [
    { label: "Dashboard", path: "/", icon: LayoutDashboard },
    { label: "Contacts", path: "/contacts", icon: Users },
    { label: "Volunteers", path: "/volunteers", icon: Users },
    { label: "Templates", path: "/templates", icon: MessageSquare },
    { label: "Batch Generator", path: "/batch-generator", icon: Zap },
    { label: "Instructions", path: "/instructions", icon: BookOpen },
    { label: "Import/Export", path: "/import-export", icon: Upload },
  ];

  if (user?.role === "admin") {
    navItems.push({ label: "Admin Panel", path: "/admin", icon: Settings });
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-blue-50 via-blue-50 to-blue-100">
      {/* Sidebar */}
      <div className="w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white flex flex-col shadow-xl">
        <div className="p-6 border-b border-blue-700">
          <h1 className="text-xl font-bold">Ferguson 2026</h1>
          <p className="text-xs text-blue-200 mt-1">Campaign Manager</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? "bg-cyan-500 text-white shadow-lg"
                    : "text-blue-100 hover:bg-blue-700 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-blue-700">
          <div className="text-xs text-blue-200 mb-3 truncate">{user?.name || user?.email}</div>
          <Button
            onClick={() => logout()}
            variant="outline"
            className="w-full text-xs bg-blue-700 hover:bg-blue-600 text-white border-blue-600"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
