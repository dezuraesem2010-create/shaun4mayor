import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Contacts from "./pages/Contacts";
import Volunteers from "./pages/Volunteers";
import Templates from "./pages/Templates";
import BatchGenerator from "./pages/BatchGenerator";
import Instructions from "./pages/Instructions";
import ImportExport from "./pages/ImportExport";
import AdminPanel from "./pages/AdminPanel";
import VolunteerDashboard from "./pages/VolunteerDashboard";
import Layout from "./components/Layout";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/contacts" component={Contacts} />
        <Route path="/volunteers" component={Volunteers} />
        <Route path="/templates" component={Templates} />
        <Route path="/batch-generator" component={BatchGenerator} />
        <Route path="/instructions" component={Instructions} />
        <Route path="/import-export" component={ImportExport} />
        <Route path="/admin" component={AdminPanel} />
        <Route path="/volunteer-dashboard" component={VolunteerDashboard} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
