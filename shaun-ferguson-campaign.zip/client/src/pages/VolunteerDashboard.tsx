import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Loader2, Phone, Search } from "lucide-react";
import { useState, useMemo } from "react";

export default function VolunteerDashboard() {
  const { user } = useAuth();
  const { data: allVolunteers } = trpc.volunteers.list.useQuery();
  const { data: allContacts } = trpc.contacts.list.useQuery();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBatch, setSelectedBatch] = useState<number | null>(null);

  if (!user || user.role !== "user") {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-blue-900">Volunteer Dashboard</h1>
        <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-6">
          <p className="text-yellow-900">Only volunteers can access this dashboard.</p>
        </div>
      </div>
    );
  }

  // Find volunteer's assigned batch
  const volunteerAssignment = allVolunteers?.find((v: any) => v.volunteerName === user.name);
  const assignedBatchNumber = volunteerAssignment?.batchNumber;

  // Get contacts for this batch
  const batchContacts = useMemo(() => {
    if (!allContacts || !assignedBatchNumber) return [];
    return allContacts.filter((c: any) => c.assignedBatch === assignedBatchNumber);
  }, [allContacts, assignedBatchNumber]);

  // Filter by search term
  const filteredContacts = useMemo(() => {
    if (!searchTerm.trim()) return batchContacts;
    const term = searchTerm.toLowerCase();
    return batchContacts.filter((contact: any) =>
      contact.name.toLowerCase().includes(term) ||
      contact.phone.includes(term) ||
      contact.neighborhood?.toLowerCase().includes(term)
    );
  }, [batchContacts, searchTerm]);

  // Calculate stats
  const totalContacts = batchContacts.length;
  const contactedCount = batchContacts.filter((c: any) => c.contacted).length;
  const supportersCount = batchContacts.filter((c: any) => c.responseStatus === "Supporter").length;
  const volunteersCount = batchContacts.filter((c: any) => c.responseStatus === "Volunteer").length;
  const contactedPercentage = totalContacts > 0 ? Math.round((contactedCount / totalContacts) * 100) : 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Supporter":
        return "bg-green-200 text-green-900";
      case "Opposed":
        return "bg-red-200 text-red-900";
      case "Undecided":
        return "bg-yellow-200 text-yellow-900";
      case "Volunteer":
        return "bg-blue-200 text-blue-900";
      case "Do Not Contact":
        return "bg-slate-200 text-slate-900";
      default:
        return "bg-gray-200 text-gray-900";
    }
  };

  if (!assignedBatchNumber) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-blue-900">Volunteer Dashboard</h1>
        <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-6">
          <p className="text-blue-900">You have not been assigned to a batch yet. Please contact the campaign manager.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-blue-900">My Batch Dashboard</h1>
        <p className="text-sm text-blue-700 mt-1">Batch {assignedBatchNumber} - {volunteerAssignment?.volunteerName}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-4 rounded-lg text-white border-2 border-blue-300">
          <div className="text-xs font-semibold text-blue-100">Total Contacts</div>
          <div className="text-3xl font-bold mt-2">{totalContacts}</div>
        </div>
        <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 p-4 rounded-lg text-white border-2 border-cyan-300">
          <div className="text-xs font-semibold text-cyan-100">Contacted</div>
          <div className="text-3xl font-bold mt-2">{contactedCount}</div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 p-4 rounded-lg text-white border-2 border-green-300">
          <div className="text-xs font-semibold text-green-100">Supporters</div>
          <div className="text-3xl font-bold mt-2">{supportersCount}</div>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-4 rounded-lg text-white border-2 border-purple-300">
          <div className="text-xs font-semibold text-purple-100">Volunteers</div>
          <div className="text-3xl font-bold mt-2">{volunteersCount}</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 rounded-lg text-white border-2 border-blue-400">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-sm font-semibold text-blue-100">Batch Progress</div>
            <div className="text-4xl font-bold mt-2">{contactedPercentage}%</div>
          </div>
          <div className="w-24 h-24 rounded-full bg-blue-500 flex items-center justify-center">
            <div className="text-center">
              <div className="text-2xl font-bold">{contactedPercentage}%</div>
            </div>
          </div>
        </div>
        <div className="w-full bg-blue-400 rounded-full h-3">
          <div
            className="bg-cyan-400 h-3 rounded-full transition-all"
            style={{ width: `${contactedPercentage}%` }}
          ></div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-3 w-5 h-5 text-blue-400" />
        <input
          type="text"
          placeholder="Search contacts by name, phone, or neighborhood..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-3 border-2 border-blue-300 rounded-lg focus:outline-none focus:border-blue-600"
        />
      </div>

      {/* Contacts Table */}
      <div className="bg-white rounded-lg border-2 border-blue-300 overflow-hidden shadow-lg">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-4 border-b-2 border-blue-400">
          <h2 className="text-lg font-bold text-white">Contacts to Contact ({filteredContacts.length})</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-blue-50 border-b-2 border-blue-300">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">ID</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Name</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Phone</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Neighborhood</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Contacted</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredContacts.length > 0 ? (
                filteredContacts.map((contact: any) => (
                  <tr key={contact.contactId} className="border-b border-blue-100 hover:bg-blue-50">
                    <td className="py-3 px-4 font-medium text-blue-900">{contact.contactId}</td>
                    <td className="py-3 px-4 text-blue-800 font-semibold">{contact.name}</td>
                    <td className="py-3 px-4 text-blue-800">{contact.phone}</td>
                    <td className="py-3 px-4 text-blue-800">{contact.neighborhood || "—"}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${getStatusColor(contact.responseStatus)}`}>
                        {contact.responseStatus || "No Response"}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold ${
                          contact.contacted
                            ? "bg-green-200 text-green-900"
                            : "bg-slate-200 text-slate-900"
                        }`}
                      >
                        {contact.contacted ? "Yes" : "No"}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <a
                        href={`tel:${contact.phone}`}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-xs font-semibold"
                      >
                        <Phone className="w-4 h-4" />
                        Call
                      </a>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-blue-600">
                    No contacts found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Instructions */}
      <div className="bg-blue-50 rounded-lg border-2 border-blue-300 p-6">
        <h3 className="text-lg font-bold text-blue-900 mb-4">How to Use Google Voice</h3>
        <ol className="list-decimal list-inside space-y-2 text-blue-800">
          <li>Click the "Call" button to initiate a call using your phone</li>
          <li>After speaking with the contact, update their response status</li>
          <li>Mark "Contacted" as Yes once you've reached them</li>
          <li>Track your progress on the progress bar above</li>
        </ol>
      </div>
    </div>
  );
}
