import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Loader2, Plus, Edit2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Contacts() {
  const { user } = useAuth();
  const { data: contacts, isLoading, refetch } = trpc.contacts.list.useQuery();
  const createMutation = trpc.contacts.create.useMutation();
  const updateMutation = trpc.contacts.update.useMutation();
  
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    contactId: 0,
    name: "",
    phone: "",
    precinct: "",
    neighborhood: "",
    assignedBatch: "",
    assignedVolunteer: "",
    contacted: "No",
    responseStatus: "No Response Yet",
    volunteerInterest: "No",
    doNotContact: "No",
    notes: "",
  });

  const responseOptions = ["Supporter", "Opposed", "Undecided", "Volunteer", "Do Not Contact", "No Response Yet"];

  const handleSubmit = async () => {
    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          contactId: editingId,
          name: formData.name || undefined,
          phone: formData.phone || undefined,
          precinct: formData.precinct || undefined,
          neighborhood: formData.neighborhood || undefined,
          assignedBatch: formData.assignedBatch ? parseInt(formData.assignedBatch) : undefined,
          assignedVolunteer: formData.assignedVolunteer || undefined,
          contacted: formData.contacted === "Yes",
          responseStatus: formData.responseStatus as any,
          doNotContact: formData.doNotContact === "Yes",
          notes: formData.notes || undefined,
        });
      } else {
        await createMutation.mutateAsync({
          contactId: formData.contactId,
          name: formData.name,
          phone: formData.phone,
          precinct: formData.precinct || undefined,
          neighborhood: formData.neighborhood || undefined,
          assignedBatch: formData.assignedBatch ? parseInt(formData.assignedBatch) : undefined,
          assignedVolunteer: formData.assignedVolunteer || undefined,
        });
      }
      await refetch();
      resetForm();
    } catch (error) {
      console.error("Error saving contact:", error);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingId(null);
    setFormData({
      contactId: 0,
      name: "",
      phone: "",
      precinct: "",
      neighborhood: "",
      assignedBatch: "",
      assignedVolunteer: "",
      contacted: "No",
      responseStatus: "No Response Yet",
      volunteerInterest: "No",
      doNotContact: "No",
      notes: "",
    });
  };

  const handleEdit = (contact: any) => {
    setEditingId(contact.contactId);
    setFormData({
      contactId: contact.contactId,
      name: contact.name || "",
      phone: contact.phone || "",
      precinct: contact.precinct || "",
      neighborhood: contact.neighborhood || "",
      assignedBatch: contact.assignedBatch || "",
      assignedVolunteer: contact.assignedVolunteer || "",
      contacted: contact.contacted || "No",
      responseStatus: contact.responseStatus || "No Response Yet",
      volunteerInterest: contact.volunteerInterest || "No",
      doNotContact: contact.doNotContact || "No",
      notes: contact.notes || "",
    });
    setShowForm(true);
  };

  if (isLoading) return <div className="flex items-center justify-center h-screen"><Loader2 className="animate-spin" /></div>;

  const isAdmin = user?.role === "admin";
  const isVolunteer = user?.role === "user";

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-blue-900">Contacts ({contacts?.length || 0})</h1>
        {isAdmin && <Button onClick={() => { resetForm(); setShowForm(true); }} className="bg-blue-600 hover:bg-blue-700"><Plus className="w-4 h-4 mr-2" /> Add Contact</Button>}
      </div>

      <div className="bg-white rounded-lg border-2 border-blue-300 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-blue-50 border-b-2 border-blue-300 sticky top-0">
            <tr>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">ID</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Name</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Phone</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Precinct</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Neighborhood</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Batch</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Volunteer</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Contacted</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Response</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">DNC</th>
              {isAdmin && <th className="text-center py-3 px-4 font-semibold text-blue-900">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {contacts?.map((c: any) => (
              <tr key={c.contactId} className="border-b border-blue-100 hover:bg-blue-50">
                <td className="py-3 px-4 text-blue-900">{c.contactId}</td>
                <td className="py-3 px-4 text-blue-800">{c.name || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.phone || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.precinct || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.neighborhood || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.assignedBatch || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.assignedVolunteer || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.contacted || "No"}</td>
                <td className="py-3 px-4 text-blue-800">{c.responseStatus || "—"}</td>
                <td className="py-3 px-4 text-blue-800">{c.doNotContact === "Yes" ? "✓" : "—"}</td>
                {isAdmin && (
                  <td className="py-3 px-4 text-center">
                    <button onClick={() => handleEdit(c)} className="text-blue-600 hover:text-blue-900 mr-2"><Edit2 className="w-4 h-4 inline" /></button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 border-2 border-blue-400 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-blue-900 mb-4">{editingId ? "Edit Contact" : "Add Contact"}</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Contact ID *</label>
                <input type="number" placeholder="ID" value={formData.contactId} onChange={(e) => setFormData({ ...formData, contactId: parseInt(e.target.value) })} className="w-full border-2 border-blue-300 rounded px-3 py-2" disabled={editingId ? true : false} />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Name</label>
                <input type="text" placeholder="Name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Phone</label>
                <input type="text" placeholder="Phone" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Precinct</label>
                <input type="text" placeholder="Precinct" value={formData.precinct} onChange={(e) => setFormData({ ...formData, precinct: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Neighborhood</label>
                <input type="text" placeholder="Neighborhood" value={formData.neighborhood} onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Assigned Batch</label>
                <input type="text" placeholder="Batch #" value={formData.assignedBatch} onChange={(e) => setFormData({ ...formData, assignedBatch: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Assigned Volunteer</label>
                <input type="text" placeholder="Volunteer Name" value={formData.assignedVolunteer} onChange={(e) => setFormData({ ...formData, assignedVolunteer: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Contacted</label>
                <select value={formData.contacted} onChange={(e) => setFormData({ ...formData, contacted: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2">
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Response Status</label>
                <select value={formData.responseStatus} onChange={(e) => setFormData({ ...formData, responseStatus: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2">
                  {responseOptions.map(opt => <option key={opt}>{opt}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Volunteer Interest</label>
                <select value={formData.volunteerInterest} onChange={(e) => setFormData({ ...formData, volunteerInterest: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2">
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-1">Do Not Contact</label>
                <select value={formData.doNotContact} onChange={(e) => setFormData({ ...formData, doNotContact: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2">
                  <option>No</option>
                  <option>Yes</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-sm font-semibold text-blue-900 mb-1">Notes</label>
                <textarea placeholder="Notes" value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2 h-20" />
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50">{createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save"}</Button>
              <Button onClick={resetForm} variant="outline" className="flex-1">Cancel</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
