export default function AdminPanel() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-900">Admin Panel</h1>
      <div className="bg-white rounded-lg border-2 border-blue-300 p-6">
        <p className="text-blue-800">Admin features coming soon...</p>
      </div>
    </div>
  );
}
