export default function Instructions() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-900">Volunteer Instructions</h1>
      <div className="bg-white rounded-lg border-2 border-blue-300 p-6 space-y-4">
        <div>
          <h3 className="text-lg font-bold text-blue-900 mb-2">Step 1: Find Your Batch</h3>
          <p className="text-blue-800">Go to Contacts and search for your assigned batch number to see all contacts you need to reach.</p>
        </div>
        <div>
          <h3 className="text-lg font-bold text-blue-900 mb-2">Step 2: Use Google Voice</h3>
          <p className="text-blue-800">Open Google Voice and send text messages to each contact using the provided message templates.</p>
        </div>
        <div>
          <h3 className="text-lg font-bold text-blue-900 mb-2">Step 3: Log Responses</h3>
          <p className="text-blue-800">Return to the Contacts page and update each contact's response status (Supporter, Opposed, Undecided, etc.)</p>
        </div>
        <div>
          <h3 className="text-lg font-bold text-blue-900 mb-2">Step 4: Complete Batch</h3>
          <p className="text-blue-800">Once all contacts are reached, mark your batch as Completed in the Volunteers page.</p>
        </div>
      </div>
    </div>
  );
}
