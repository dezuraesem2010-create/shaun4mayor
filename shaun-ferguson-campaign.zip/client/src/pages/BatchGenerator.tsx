export default function BatchGenerator() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-900">Batch Generator</h1>
      <div className="bg-white rounded-lg border-2 border-blue-300 p-6">
        <p className="text-blue-800 mb-4">Configure batch sizes and generate volunteer batch assignments.</p>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-blue-900 mb-2">Batch Size</label>
            <input type="number" defaultValue="150" className="w-full border-2 border-blue-300 rounded px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-blue-900 mb-2">Total Contacts</label>
            <input type="number" defaultValue="9000" className="w-full border-2 border-blue-300 rounded px-3 py-2" />
          </div>
          <button className="w-full bg-blue-600 text-white py-2 rounded font-semibold hover:bg-blue-700">Generate Batches</button>
        </div>
      </div>
    </div>
  );
}
