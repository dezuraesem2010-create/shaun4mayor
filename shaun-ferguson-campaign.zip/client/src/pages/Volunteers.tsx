import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Loader2, Plus } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Volunteers() {
  const { user } = useAuth();
  const { data: assignments, isLoading, refetch } = trpc.volunteers.list.useQuery();
  const createMutation = trpc.volunteers.create.useMutation();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ batchNumber: 1, volunteerName: "", startContactId: 1, endContactId: 150, totalContacts: 150 });

  const handleSubmit = async () => {
    await createMutation.mutateAsync(formData);
    refetch();
    setShowForm(false);
  };

  if (isLoading) return <div className="flex items-center justify-center h-screen"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-blue-900">Volunteer Batches (60 Total)</h1>
        {user?.role === "admin" && <Button onClick={() => setShowForm(true)} className="bg-blue-600"><Plus className="w-4 h-4 mr-2" /> Assign</Button>}
      </div>
      <div className="bg-white rounded-lg border-2 border-blue-300 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-blue-50 border-b-2 border-blue-300">
            <tr>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Batch</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Volunteer</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Status</th>
              <th className="text-left py-3 px-4 font-semibold text-blue-900">Contacts</th>
            </tr>
          </thead>
          <tbody>
            {assignments?.map((a: any) => (
              <tr key={a.id} className="border-b border-blue-100 hover:bg-blue-50">
                <td className="py-3 px-4 font-medium text-blue-900">Batch {a.batchNumber}</td>
                <td className="py-3 px-4 text-blue-800">{a.volunteerName || "—"}</td>
                <td className="py-3 px-4"><span className={`px-2 py-1 rounded text-xs font-semibold ${a.progressStatus === "Completed" ? "bg-cyan-200" : "bg-slate-200"}`}>{a.progressStatus}</span></td>
                <td className="py-3 px-4 text-blue-800">{a.totalContacts}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 border-2 border-blue-400 w-96">
            <h2 className="text-2xl font-bold text-blue-900 mb-4">Assign Volunteer</h2>
            <input type="number" placeholder="Batch #" value={formData.batchNumber} onChange={(e) => setFormData({ ...formData, batchNumber: parseInt(e.target.value) })} className="w-full border-2 border-blue-300 rounded px-3 py-2 mb-3" />
            <input type="text" placeholder="Volunteer Name" value={formData.volunteerName} onChange={(e) => setFormData({ ...formData, volunteerName: e.target.value })} className="w-full border-2 border-blue-300 rounded px-3 py-2 mb-3" />
            <div className="flex gap-2">
              <Button onClick={handleSubmit} className="flex-1 bg-blue-600">Save</Button>
              <Button onClick={() => setShowForm(false)} variant="outline" className="flex-1">Cancel</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
