import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Loader2, X, Search } from "lucide-react";
import { useState, useMemo } from "react";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: metrics, isLoading } = trpc.dashboard.getMetrics.useQuery();
  const { data: batchSummary } = trpc.dashboard.getBatchSummary.useQuery();
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { data: contactList, isLoading: isLoadingContacts } = trpc.dashboard.getContactsByCategory.useQuery(
    { category: selectedMetric || "" },
    { enabled: !!selectedMetric }
  );

  // Filter contacts by search term - must be before conditional returns
  const filteredContacts = useMemo(() => {
    if (!contactList || contactList.length === 0) return [];
    if (!searchTerm.trim()) return contactList;
    
    const term = searchTerm.toLowerCase();
    return contactList.filter((contact: any) =>
      contact.name.toLowerCase().includes(term) ||
      contact.phone.includes(term) ||
      (contact.precinct && contact.precinct.toLowerCase().includes(term)) ||
      (contact.neighborhood && contact.neighborhood.toLowerCase().includes(term))
    );
  }, [contactList, searchTerm]);

  if (isLoading || !metrics) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="animate-spin w-8 h-8 text-blue-600" />
      </div>
    );
  }

  const metricCards = [
    { key: "total", label: "Total Contacts", value: metrics.totalContacts, color: "from-blue-600 to-blue-700" },
    { key: "assigned", label: "Assigned", value: metrics.contactsAssigned, color: "from-blue-500 to-blue-600" },
    { key: "completed", label: "Completed", value: metrics.contactsCompleted, color: "from-slate-500 to-slate-600" },
    { key: "supporters", label: "Supporters", value: metrics.supporters, color: "from-cyan-500 to-cyan-600" },
    { key: "undecided", label: "Undecided", value: metrics.undecided, color: "from-blue-600 to-blue-700" },
    { key: "opposed", label: "Opposed", value: metrics.opposed, color: "from-slate-500 to-slate-600" },
    { key: "volunteers", label: "Volunteers", value: metrics.volunteerRecruits, color: "from-cyan-500 to-cyan-600" },
    { key: "doNotContact", label: "Do Not Contact", value: metrics.doNotContact, color: "from-slate-500 to-slate-600" },
  ];

  const getDetailTitle = (metric: string) => {
    const titles: Record<string, string> = {
      total: "All Contacts",
      assigned: "Assigned Contacts",
      completed: "Completed Contacts",
      supporters: "Supporters",
      undecided: "Undecided Voters",
      opposed: "Opposed Voters",
      volunteers: "Volunteer Recruits",
      doNotContact: "Do Not Contact List",
    };
    return titles[metric] || metric;
  };

  const getPercentage = (count: number) => {
    if (metrics.totalContacts === 0) return "0%";
    return `${((count / metrics.totalContacts) * 100).toFixed(1)}%`;
  };


  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-blue-900">Campaign Dashboard</h1>
        <p className="text-sm text-blue-700 mt-1">Shaun Ferguson for Mayor 2026 – Live Metrics</p>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {metricCards.map((card) => (
          <button
            key={card.key}
            onClick={() => {
              setSelectedMetric(card.key);
              setSearchTerm("");
            }}
            className={`bg-gradient-to-br ${card.color} p-4 rounded-lg text-white hover:shadow-xl transition-all cursor-pointer border-2 border-blue-300`}
          >
            <div className="text-xs font-semibold text-blue-100">{card.label}</div>
            <div className="text-3xl font-bold mt-2">{card.value}</div>
          </button>
        ))}
      </div>

      {/* Completion Progress */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 rounded-lg text-white border-2 border-blue-400">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-sm font-semibold text-blue-100">Campaign Completion</div>
            <div className="text-4xl font-bold mt-2">{metrics.completionPercentage}%</div>
          </div>
          <div className="w-24 h-24 rounded-full bg-blue-500 flex items-center justify-center">
            <div className="text-center">
              <div className="text-2xl font-bold">{metrics.completionPercentage}%</div>
            </div>
          </div>
        </div>
        <div className="w-full bg-blue-400 rounded-full h-3">
          <div
            className="bg-cyan-400 h-3 rounded-full transition-all"
            style={{ width: `${metrics.completionPercentage}%` }}
          ></div>
        </div>
      </div>

      {/* Batch Summary Table with Progress */}
      <div className="bg-white rounded-lg border-2 border-blue-300 overflow-hidden shadow-lg">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-4 border-b-2 border-blue-400">
          <h2 className="text-lg font-bold text-white">Batch Summary (60 Batches)</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-blue-50 border-b-2 border-blue-300">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Batch</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Volunteer</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Progress</th>
                <th className="text-left py-3 px-4 font-semibold text-blue-900">Contacts</th>
              </tr>
            </thead>
            <tbody>
              {batchSummary?.slice(0, 10).map((batch: any) => {
                const progressPercent = Math.round((batch.contactsCompleted || 0) / batch.totalContacts * 100);
                return (
                  <tr key={batch.batchNumber} className="border-b border-blue-100 hover:bg-blue-50">
                    <td className="py-3 px-4 font-medium text-blue-900">Batch {batch.batchNumber}</td>
                    <td className="py-3 px-4 text-blue-800">{batch.volunteerName || "—"}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          batch.progressStatus === "Completed"
                            ? "bg-cyan-200 text-cyan-900"
                            : batch.progressStatus === "In Progress"
                              ? "bg-blue-200 text-blue-900"
                              : "bg-slate-200 text-slate-900"
                        }`}
                      >
                        {batch.progressStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-24 bg-slate-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${progressPercent}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-semibold text-blue-900">{progressPercent}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-blue-800">{batch.totalContacts}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Contact List Modal with Search */}
      {selectedMetric && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-5xl w-full p-6 border-2 border-blue-400 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-blue-900">{getDetailTitle(selectedMetric)}</h2>
              <button
                onClick={() => {
                  setSelectedMetric(null);
                  setSearchTerm("");
                }}
                className="p-2 hover:bg-blue-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-blue-900" />
              </button>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xs text-blue-600 font-semibold mb-2">Total Count</div>
                <div className="text-3xl font-bold text-blue-900">{filteredContacts.length}</div>
              </div>
              <div className="p-4 bg-cyan-50 rounded-lg border border-cyan-200">
                <div className="text-xs text-cyan-600 font-semibold mb-2">Percentage</div>
                <div className="text-3xl font-bold text-cyan-900">{getPercentage(filteredContacts.length)}</div>
              </div>
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-xs text-slate-600 font-semibold mb-2">Remaining</div>
                <div className="text-3xl font-bold text-slate-900">
                  {metrics.totalContacts - filteredContacts.length}
                </div>
              </div>
            </div>

            {/* Search Bar */}
            <div className="mb-6 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-blue-400" />
              <input
                type="text"
                placeholder="Search by name, phone, precinct, or neighborhood..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border-2 border-blue-300 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            {/* Contact List */}
            {isLoadingContacts ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="animate-spin w-6 h-6 text-blue-600" />
              </div>
            ) : filteredContacts && filteredContacts.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-blue-50 border-b-2 border-blue-300 sticky top-0">
                    <tr>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">ID</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Name</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Phone</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Precinct</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Neighborhood</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Batch</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Volunteer</th>
                      <th className="text-left py-3 px-4 font-semibold text-blue-900">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredContacts.map((contact: any) => (
                      <tr key={contact.contactId} className="border-b border-blue-100 hover:bg-blue-50">
                        <td className="py-3 px-4 font-medium text-blue-900">{contact.contactId}</td>
                        <td className="py-3 px-4 text-blue-800 font-semibold">{contact.name}</td>
                        <td className="py-3 px-4 text-blue-800">{contact.phone}</td>
                        <td className="py-3 px-4 text-blue-800">{contact.precinct || "—"}</td>
                        <td className="py-3 px-4 text-blue-800">{contact.neighborhood || "—"}</td>
                        <td className="py-3 px-4 text-blue-800">{contact.assignedBatch || "—"}</td>
                        <td className="py-3 px-4 text-blue-800">{contact.assignedVolunteer || "—"}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-1 rounded text-xs font-semibold ${
                              contact.responseStatus === "Supporter"
                                ? "bg-green-200 text-green-900"
                                : contact.responseStatus === "Opposed"
                                  ? "bg-red-200 text-red-900"
                                  : contact.responseStatus === "Undecided"
                                    ? "bg-yellow-200 text-yellow-900"
                                    : contact.responseStatus === "Volunteer"
                                      ? "bg-blue-200 text-blue-900"
                                      : contact.doNotContact
                                        ? "bg-slate-200 text-slate-900"
                                        : "bg-gray-200 text-gray-900"
                            }`}
                          >
                            {contact.responseStatus || "No Response"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-blue-600">
                <p>No contacts found matching your search.</p>
              </div>
            )}

            <button
              onClick={() => {
                setSelectedMetric(null);
                setSearchTerm("");
              }}
              className="w-full mt-6 bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
