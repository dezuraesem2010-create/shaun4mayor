import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Upload, Download, AlertCircle, CheckCircle } from "lucide-react";
import Papa from "papaparse";

export default function ImportExport() {
  const { user } = useAuth();
  const bulkImportMutation = trpc.contacts.bulkImport.useMutation();
  const { data: allContacts } = trpc.contacts.list.useQuery();
  
  const [importProgress, setImportProgress] = useState<{ total: number; processed: number } | null>(null);
  const [importStatus, setImportStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [importMessage, setImportMessage] = useState("");

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus("loading");
    setImportMessage("");
    setImportProgress(null);

    Papa.parse(file as any, {
      header: true,
      skipEmptyLines: true,
      complete: async (results: any) => {
        const rows = results.data as any[];
        if (rows.length === 0) return;

        try {
          setImportProgress({ total: rows.length, processed: 0 });

          const contacts = rows.map((row: any) => ({
            contactId: parseInt(row.contactId) || 0,
            name: row.name || "",
            phone: row.phone || "",
            precinct: row.precinct || "",
            neighborhood: row.neighborhood || "",
            assignedBatch: row.assignedBatch ? parseInt(row.assignedBatch) : undefined,
            assignedVolunteer: row.assignedVolunteer || undefined,
          }));

          await bulkImportMutation.mutateAsync({ contacts });
          setImportProgress((prev) => prev ? { ...prev, processed: prev.total } : null);
          setImportStatus("success");
          setImportMessage(`Successfully imported ${rows.length} contacts!`);
          (e.target as HTMLInputElement).value = "";
        } catch (error: any) {
          setImportStatus("error");
          setImportMessage(`Error importing contacts: ${error.message}`);
        }
      },
      error: (error: any) => {
        setImportStatus("error");
        setImportMessage(`CSV parsing error: ${error.message}`);
      },
    });
  };

  const handleExport = async () => {
    try {
      const data = allContacts || [];
      
      // Create CSV from contacts
      const rows = [
        ["contactId", "name", "phone", "precinct", "neighborhood", "assignedBatch", "assignedVolunteer", "contacted", "responseStatus", "doNotContact", "notes"],
        ...data.map((c: any) => [
          c.contactId,
          c.name,
          c.phone,
          c.precinct || "",
          c.neighborhood || "",
          c.assignedBatch || "",
          c.assignedVolunteer || "",
          c.contacted ? "Yes" : "No",
          c.responseStatus || "",
          c.doNotContact ? "Yes" : "No",
          c.notes || "",
        ]),
      ];
      const csv = rows
        .map((row: any[]) => row.map((cell: any) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
        .join("\n");

      // Download CSV
      const blob = new Blob([csv], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `contacts-${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      alert(`Export failed: ${error.message}`);
    }
  };

  if (user?.role !== "admin") {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-blue-900">Import/Export</h1>
        <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-6">
          <p className="text-yellow-900">Only administrators can access import/export features.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-900">Import/Export</h1>
      
      <div className="grid md:grid-cols-2 gap-6">
        {/* Import Section */}
        <div className="bg-white rounded-lg border-2 border-blue-300 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Upload className="text-blue-600" size={24} />
            <h3 className="text-lg font-bold text-blue-900">Import Contacts</h3>
          </div>
          <p className="text-blue-800 mb-4 text-sm">
            Upload a CSV file with columns: contactId, name, phone, precinct, neighborhood, assignedBatch (optional), assignedVolunteer (optional)
          </p>
          
          <input
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            disabled={bulkImportMutation.isPending}
            className="w-full border-2 border-blue-300 rounded px-3 py-2 mb-4 disabled:opacity-50 hidden"
          />
          
          {importProgress && (
            <div className="mb-4">
              <div className="flex justify-between text-sm text-blue-800 mb-2">
                <span>Progress</span>
                <span>{importProgress.processed} / {importProgress.total}</span>
              </div>
              <div className="w-full bg-blue-100 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: `${(importProgress.processed / importProgress.total) * 100}%` }}
                />
              </div>
            </div>
          )}

          {importStatus === "success" && (
            <div className="flex items-center gap-2 text-green-700 bg-green-50 border border-green-300 rounded p-3 mb-4">
              <CheckCircle size={20} />
              <span>{importMessage}</span>
            </div>
          )}

          {importStatus === "error" && (
            <div className="flex items-center gap-2 text-red-700 bg-red-50 border border-red-300 rounded p-3 mb-4">
              <AlertCircle size={20} />
              <span>{importMessage}</span>
            </div>
          )}

          <Button
            onClick={() => {
              const input = document.querySelector('input[type="file"]') as HTMLInputElement;
              input?.click();
            }}
            disabled={bulkImportMutation.isPending}
            className="w-full bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50"
          >
            {bulkImportMutation.isPending ? "Importing..." : "Select CSV File"}
          </Button>
        </div>

        {/* Export Section */}
        <div className="bg-white rounded-lg border-2 border-blue-300 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Download className="text-blue-600" size={24} />
            <h3 className="text-lg font-bold text-blue-900">Export Data</h3>
          </div>
          <p className="text-blue-800 mb-4 text-sm">
            Download all contacts and campaign data as CSV
          </p>
          
          <Button
            onClick={handleExport}
            className="w-full bg-blue-600 text-white hover:bg-blue-700"
          >
            Export Contacts (CSV)
          </Button>

          <div className="mt-4 p-4 bg-blue-50 rounded border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Tip:</strong> Export your data regularly to create backups of all contacts, responses, and campaign progress.
            </p>
          </div>
        </div>
      </div>

      {/* CSV Format Guide */}
      <div className="bg-blue-50 rounded-lg border-2 border-blue-300 p-6">
        <h3 className="text-lg font-bold text-blue-900 mb-4">CSV Format Guide</h3>
        <p className="text-blue-800 mb-3">Your CSV file should have the following columns:</p>
        <div className="bg-white rounded p-4 font-mono text-sm text-blue-900 overflow-x-auto">
          <code>
            contactId,name,phone,precinct,neighborhood,assignedBatch,assignedVolunteer<br />
            1,John Smith,555-0101,Precinct 1,Downtown,1,<br />
            2,Jane Doe,555-0102,Precinct 2,Midtown,1,<br />
            3,Bob Johnson,555-0103,Precinct 3,Uptown,2,
          </code>
        </div>
        <p className="text-blue-800 mt-3 text-sm">
          <strong>Required fields:</strong> contactId, name, phone<br />
          <strong>Optional fields:</strong> precinct, neighborhood, assignedBatch, assignedVolunteer
        </p>
      </div>
    </div>
  );
}
