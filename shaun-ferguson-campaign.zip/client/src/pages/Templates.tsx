import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2, Copy, Check } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Templates() {
  const { user } = useAuth();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const templates_data = [
    {
      id: "A",
      theme: "Community Focus",
      text: "Hello! This is a volunteer with the Shaun Ferguson for Mayor campaign. Shaun is committed to strengthening Rockledge neighborhoods and supporting local families. Can we count on your support?\n\nPaid for by Shaun Ferguson for Mayor 2026. Reply STOP to opt out."
    },
    {
      id: "B",
      theme: "Leadership Experience",
      text: "Shaun Ferguson has years of leadership experience serving our community and is ready to bring that experience to Rockledge City Hall. Can he count on your support?\n\nPaid for by Shaun Ferguson for Mayor 2026. Reply STOP to opt out."
    },
    {
      id: "C",
      theme: "Local Priorities",
      text: "Shaun Ferguson is focused on improving neighborhood safety, strengthening infrastructure, and supporting Rockledge residents. May we count on your support?\n\nPaid for by Shaun Ferguson for Mayor 2026. Reply STOP to opt out."
    },
    {
      id: "D",
      theme: "Community Unity",
      text: "Shaun Ferguson believes strong communities are built through service, unity, and leadership. He is ready to serve Rockledge as Mayor. Can we count on your support?\n\nPaid for by Shaun Ferguson for Mayor 2026. Reply STOP to opt out."
    },
    {
      id: "E",
      theme: "Civic Commitment",
      text: "Shaun Ferguson is committed to keeping Rockledge strong, connected, and prepared for the future. Can we count on your support?\n\nPaid for by Shaun Ferguson for Mayor 2026. Reply STOP to opt out."
    }
  ];

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold text-blue-900 mb-2">Message Templates</h1>
        <p className="text-blue-700 text-sm">Rotate through templates A → B → C → D → E, then repeat. Change template every 10–20 contacts to reduce carrier filtering.</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {templates_data.map((template) => (
          <div key={template.id} className="bg-white rounded-lg border-2 border-blue-300 p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-blue-900">Template {template.id}</h2>
                <p className="text-blue-700 font-semibold">{template.theme}</p>
              </div>
              <Button 
                onClick={() => handleCopy(template.text, template.id)}
                className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2 whitespace-nowrap"
              >
                {copiedId === template.id ? (
                  <>
                    <Check className="w-4 h-4" /> Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" /> Copy
                  </>
                )}
              </Button>
            </div>

            <div className="bg-blue-50 rounded p-4 border border-blue-200">
              <p className="text-blue-900 whitespace-pre-wrap text-sm leading-relaxed font-sans">{template.text}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-100 border-2 border-blue-400 rounded-lg p-6">
        <h3 className="text-lg font-bold text-blue-900 mb-3">Rotation Guidance</h3>
        <ul className="space-y-2 text-blue-900 text-sm">
          <li><strong>Cycle:</strong> Templates A → B → C → D → E, then repeat</li>
          <li><strong>Frequency:</strong> Change template every 10–20 contacts</li>
          <li><strong>Purpose:</strong> Reduces carrier filtering and improves delivery rates</li>
          <li><strong>Pacing:</strong> Send no more than 150 texts per session</li>
          <li><strong>Timing:</strong> Avoid sending texts before 9:00 AM or after 8:00 PM local time</li>
        </ul>
      </div>
    </div>
  );
}
